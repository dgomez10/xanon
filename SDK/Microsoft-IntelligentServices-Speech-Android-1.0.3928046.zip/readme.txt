Microsoft Speech SDK
====================

This library provides you with everything you need to integrating Speech Recognition into your application.

NOTE: By default, the Microsoft Speech SDK for iOS is installed in ~/Documents/SpeechSDK

FEATURES
--------
* Short-form recognition.
* Long-form dictation.
* Recognition with intent.
* Integrated microphone support.
* External audio support.

LICENSE
-------
� 2014 Microsoft. All rights reserved.  
This document is provided �as-is�. Information and views expressed in this document, including URL and other Internet Web site references, may change without notice.  
Some examples depicted herein are provided for illustration only and are fictitious.  No real association or connection is intended or should be inferred. 
This document does not provide you with any legal rights to any intellectual property in any Microsoft product. You may copy and use this document for your internal, reference purposes. This document is confidential and proprietary to Microsoft. It is disclosed and can be used only pursuant to a non-disclosure agreement. 
